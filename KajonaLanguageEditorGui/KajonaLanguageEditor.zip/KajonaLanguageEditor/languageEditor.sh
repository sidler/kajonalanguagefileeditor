#!/bin/bash
java -jar ./dist/KajonaLanguageEditorGui.jar 
